# WassControlSys v0.1.1 - Notas de la Versión

## 📦 Información de la Versión

- **Versión:** 0.1.1
- **Fecha de Lanzamiento:** 8 de Diciembre, 2025
- **Plataforma:** Windows x64
- **Framework:** .NET 8.0

---

## 🎉 Novedades en v0.1.1

### ✨ Nuevas Características

#### 1. **Sistema de Colores Dinámicos**
- ✅ Cambio de color de acento en tiempo real
- ✅ 5 colores predefinidos (Azul, Verde, Rojo, Púrpura, Naranja)
- ✅ Todos los elementos de la UI se actualizan dinámicamente
- ✅ Persistencia del color seleccionado

#### 2. **Tipografía Roboto**
- ✅ Fuente Roboto en toda la aplicación
- ✅ Mejor legibilidad y aspecto moderno
- ✅ Tamaños de fuente optimizados

#### 3. **Controles de Ventana Personalizados**
- ✅ Barra de título personalizada
- ✅ Botones de minimizar, maximizar/restaurar y cerrar
- ✅ Diseño integrado con el tema de la aplicación
- ✅ Redimensionamiento desde todos los bordes

#### 4. **Módulo de Optimización Expandido**
- ✅ Limpiar Caché DNS
- ✅ Análisis de Disco
- ✅ Reconstruir Índice de Búsqueda
- ✅ Limpiar Prefetch
- ✅ Reiniciar Configuración de Red

#### 5. **Opciones de Limpieza Personalizables**
- ✅ Seleccionar qué limpiar (Papelera, Caché, Temporales)
- ✅ Checkboxes para control granular
- ✅ Feedback mejorado con salida de comandos

#### 6. **Vista de Servicios Mejorada**
- ✅ Scroll vertical y horizontal funcional
- ✅ Fuentes más grandes (15-16px)
- ✅ Nombres de servicios con word wrap
- ✅ Columnas más anchas y legibles
- ✅ Hover effect en filas

#### 7. **Resaltado de Navegación**
- ✅ Sección activa resaltada con color de acento
- ✅ Indicador visual claro de la ubicación actual

---

## 🔧 Mejoras Técnicas

### Arquitectura
- ✅ Inyección de Dependencias con Microsoft.Extensions.DependencyInjection
- ✅ Patrón MVVM completo
- ✅ Servicios modulares e interfaces

### Rendimiento
- ✅ Operaciones asíncronas para no bloquear la UI
- ✅ Virtualización en listas largas
- ✅ Carga diferida de datos

### UI/UX
- ✅ DynamicResource para temas dinámicos
- ✅ Estilos globales consistentes
- ✅ Feedback visual mejorado

---

## 📋 Módulos Incluidos

### ✅ Implementados
1. **Dashboard** - Vista general del sistema
2. **Limpieza** - Limpieza de archivos temporales
3. **Optimización** - 6 herramientas de optimización
4. **Diagnóstico** - SFC, DISM, CHKDSK
5. **Sistema** - Información del sistema
6. **Seguridad** - Estado de Antivirus, Firewall, UAC
7. **Servicios** - Administrador de servicios de Windows
8. **Inicio** - Administrador de programas de inicio
9. **Desinstalador** - Desinstalador de bloatware
10. **Privacidad** - Configuración de privacidad
11. **Configuración** - Ajustes de la aplicación

---

## 🎨 Características de Diseño

### Temas
- **Modo Oscuro** por defecto
- **5 Colores de Acento** personalizables
- **Fuente Roboto** moderna y legible

### Elementos Visuales
- Barras de progreso con color de acento
- RadioButtons y CheckBoxes estilizados
- Botones con efectos hover
- Barra de título personalizada

---

## 💻 Requisitos del Sistema

### Mínimos
- **Sistema Operativo:** Windows 10 (64-bit) o superior
- **Framework:** .NET 8.0 Runtime (se descarga automáticamente si no está instalado)
- **RAM:** 2 GB mínimo
- **Espacio en Disco:** 50 MB

### Recomendados
- **Sistema Operativo:** Windows 11 (64-bit)
- **RAM:** 4 GB o más
- **Resolución:** 1920x1080 o superior

---

## 📥 Instalación

### Opción 1: Ejecutable Portable
1. Descargar `WassControlSys.exe`
2. Ejecutar directamente (no requiere instalación)
3. Si no tienes .NET 8.0, se te pedirá descargarlo

### Opción 2: Con .NET Runtime
1. Instalar [.NET 8.0 Runtime](https://dotnet.microsoft.com/download/dotnet/8.0)
2. Ejecutar `WassControlSys.exe`

---

## 🚀 Uso

### Primera Ejecución
1. Ejecutar `WassControlSys.exe`
2. La aplicación cargará la configuración por defecto
3. Navegar por las diferentes secciones usando el menú lateral

### Funciones Principales

#### Limpieza
- Seleccionar qué limpiar (checkboxes)
- Click en "Iniciar Limpieza"
- Ver resultados (archivos eliminados, espacio liberado)

#### Optimización
- Elegir la herramienta deseada
- Click en el botón correspondiente
- Seguir las instrucciones si se requiere confirmación

#### Servicios
- Ver lista de servicios de Windows
- Iniciar/Detener servicios
- Scroll para ver todos los servicios

#### Configuración
- Cambiar color de acento
- Activar/Desactivar inicio automático
- Guardar configuración

---

## ⚠️ Notas Importantes

### Permisos de Administrador
Algunas funciones requieren permisos de administrador:
- SFC (System File Checker)
- DISM (Deployment Image Servicing)
- CHKDSK
- Iniciar/Detener servicios
- Limpiar Prefetch
- Reconstruir índice de búsqueda

**Recomendación:** Ejecutar como administrador para acceso completo a todas las funciones.

### Seguridad
- La aplicación NO envía datos a internet
- Toda la información se almacena localmente
- No se recopila información personal

---

## 🐛 Problemas Conocidos

1. **Bloatware no se muestra:** Requiere permisos de administrador para detectar algunas aplicaciones
2. **Algunos servicios no se pueden detener:** Servicios críticos del sistema están protegidos
3. **Warnings de compilación:** 106 warnings de nullability (no afectan la funcionalidad)

---

## 📝 Archivos Generados

La aplicación crea los siguientes archivos:
- `settings.json` - Configuración de la aplicación
- `app.log` - Registro de actividades

**Ubicación:** Carpeta de la aplicación

---

## 🔄 Próximas Versiones (Roadmap)

### v0.2.0 (Planificado)
- [ ] Modo claro/oscuro
- [ ] Más colores de acento
- [ ] Exportar reportes
- [ ] Programador de tareas
- [ ] Actualizaciones automáticas

### v0.3.0 (Planificado)
- [ ] Monitor de red en tiempo real
- [ ] Gestor de variables de entorno
- [ ] Editor de archivo hosts
- [ ] Limpiador de registro

---

## 📞 Soporte

Para reportar problemas o sugerencias:
- Crear un issue en el repositorio
- Incluir información del sistema
- Describir el problema detalladamente

---

## 📄 Licencia

Copyright © 2025 WassControl
Todos los derechos reservados.

---

## 🙏 Agradecimientos

Gracias por usar WassControlSys v0.1.1!

---

**Fecha de Compilación:** 8 de Diciembre, 2025
**Tamaño del Ejecutable:** ~2 MB
**Versión del Framework:** .NET 8.0
