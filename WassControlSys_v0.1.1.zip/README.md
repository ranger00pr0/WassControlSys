# WassControlSys v0.1.1

## 🚀 Sistema de Control y Optimización para Windows

WassControlSys es una aplicación completa para optimizar, limpiar y administrar tu sistema Windows.

---

## 📥 Inicio Rápido

### 1. Ejecutar la Aplicación
```
Doble click en WassControlSys.exe
```

### 2. Si no tienes .NET 8.0
- Windows te pedirá descargar .NET 8.0 Runtime
- Click en "Sí" para descargar e instalar
- Ejecutar nuevamente `WassControlSys.exe`

### 3. Para Acceso Completo
```
Click derecho en WassControlSys.exe → Ejecutar como administrador
```

---

## ✨ Características Principales

### 🧹 Limpieza
- Archivos temporales del sistema
- Caché de navegadores
- Papelera de reciclaje
- Opciones personalizables

### ⚡ Optimización
- Optimizar RAM
- Limpiar caché DNS
- Análisis de disco
- Reconstruir índice de búsqueda
- Limpiar Prefetch
- Reiniciar configuración de red

### 🔧 Diagnóstico
- SFC (System File Checker)
- DISM (Reparación de imagen)
- CHKDSK (Verificación de disco)

### 🛡️ Seguridad
- Estado de Antivirus
- Estado de Firewall
- Estado de UAC

### 🔌 Servicios
- Ver servicios de Windows
- Iniciar/Detener servicios
- Información detallada

### 🚀 Inicio
- Administrar programas de inicio
- Habilitar/Deshabilitar aplicaciones

### 🗑️ Desinstalador
- Detectar bloatware
- Desinstalar aplicaciones no deseadas

### 🔒 Privacidad
- Configurar opciones de privacidad
- Telemetría
- Ubicación
- Diagnósticos

### ⚙️ Configuración
- Cambiar color de acento
- Inicio automático con Windows
- Guardar preferencias

---

## 🎨 Personalización

### Cambiar Color de Acento
1. Ir a **Configuración**
2. Seleccionar un color (Azul, Verde, Rojo, Púrpura, Naranja)
3. El color se aplica inmediatamente en toda la app

### Inicio Automático
1. Ir a **Configuración**
2. Activar "Ejecutar al iniciar Windows"
3. La configuración se guarda automáticamente

---

## 📊 Información del Sistema

### Dashboard
- Uso de CPU en tiempo real
- Uso de RAM en tiempo real
- Uso de Disco en tiempo real
- Modo de rendimiento actual

### Sistema
- Procesador
- Memoria RAM
- Sistema Operativo
- Almacenamiento

---

## ⚠️ Importante

### Permisos de Administrador
Para usar todas las funciones, ejecuta como administrador:
- Click derecho → Ejecutar como administrador

### Funciones que Requieren Admin
- SFC, DISM, CHKDSK
- Iniciar/Detener servicios
- Limpiar Prefetch
- Reconstruir índice de búsqueda
- Algunas opciones de privacidad

---

## 🔒 Privacidad y Seguridad

- ✅ **Sin conexión a internet** - Toda la información se procesa localmente
- ✅ **Sin telemetría** - No se envían datos a ningún servidor
- ✅ **Código abierto** - Puedes revisar el código fuente
- ✅ **Sin instalación** - Ejecutable portable

---

## 📁 Archivos Generados

La aplicación crea estos archivos en su carpeta:
- `settings.json` - Tu configuración
- `app.log` - Registro de actividades

---

## 💻 Requisitos

- **Windows 10/11** (64-bit)
- **.NET 8.0 Runtime** (se descarga automáticamente)
- **2 GB RAM** mínimo
- **50 MB** espacio en disco

---

## 🆘 Solución de Problemas

### La aplicación no inicia
1. Verificar que tienes .NET 8.0 Runtime instalado
2. Ejecutar como administrador
3. Verificar que Windows Defender no esté bloqueando

### No puedo iniciar/detener servicios
- Ejecutar como administrador
- Algunos servicios críticos están protegidos por Windows

### No veo bloatware
- Ejecutar como administrador
- Algunas aplicaciones solo son visibles con permisos elevados

---

## 📝 Notas de la Versión

Ver `RELEASE_NOTES_v0.1.1.md` para detalles completos de esta versión.

---

## 📞 Contacto y Soporte

Para reportar problemas o sugerencias, crear un issue en el repositorio del proyecto.

---

## 📄 Licencia

Copyright © 2025 WassControl

---

**Versión:** 0.1.1  
**Fecha:** 8 de Diciembre, 2025  
**Tamaño:** ~2 MB  

¡Gracias por usar WassControlSys!
